package com.hexed.sampdiscordrpc

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Design system of the app (HEXED brand): reusable cards, buttons, labels and rows.
 * All colours come from res/values/colors.xml, all sizes are in dp so they scale with the screen.
 * See docs/DESIGN_SYSTEM.md.
 */
class Ui(private val ctx: Context) {

    enum class Kind { PRIMARY, OUTLINE, DANGER, GHOST }

    class InfoRow(val root: LinearLayout, val dot: View, val value: TextView)

    private val density = ctx.resources.displayMetrics.density

    fun dp(v: Int): Int = (v * density + 0.5f).toInt()
    fun dpf(v: Int): Float = v * density
    fun c(id: Int): Int = ctx.getColor(id)

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    // ---------------------------------------------------------------- containers

    /** Surface panel: rounded, 1dp brand border. */
    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(PAD_CARD), dp(PAD_CARD), dp(PAD_CARD), dp(PAD_CARD))
        background = GradientDrawable().apply {
            cornerRadius = dpf(RADIUS_CARD)
            setColor(c(R.color.hx_surface))
            setStroke(dp(1), c(R.color.hx_border))
        }
    }

    fun divider(): View = View(ctx).apply {
        setBackgroundColor(c(R.color.hx_divider))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

    // ---------------------------------------------------------------- typography

    fun text(
        s: CharSequence,
        sizeSp: Float,
        colorId: Int,
        family: String = "sans-serif"
    ): TextView = TextView(ctx).apply {
        text = s
        textSize = sizeSp
        setTextColor(c(colorId))
        typeface = Typeface.create(family, Typeface.NORMAL)
    }

    fun screenTitle(s: String): TextView =
        text(s, 26f, R.color.hx_text, "sans-serif-medium").apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.01f
        }

    fun overline(s: String): TextView =
        text(s.uppercase(), 12f, R.color.hx_text_muted, "sans-serif-medium").apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        }

    fun sectionLabel(s: String): TextView =
        text(s.uppercase(), 12f, R.color.hx_brand_light, "sans-serif-medium").apply {
            letterSpacing = 0.16f
        }

    fun caption(s: String): TextView = text(s, 13f, R.color.hx_text_muted)

    // ---------------------------------------------------------------- indicators

    fun dot(sizeDp: Int, color: Int): View = View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setDot(dot: View, color: Int) {
        (dot.background as? GradientDrawable)?.setColor(color)
    }

    /** "label ........ ● value" row used in the status card. */
    fun infoRow(label: String): InfoRow {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val lab = text(label, 14f, R.color.hx_text_muted).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val d = dot(8, c(R.color.hx_text_disabled)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(8)
        }
        val v = text("", 14f, R.color.hx_text, "sans-serif-medium")
        row.addView(lab)
        row.addView(d)
        row.addView(v)
        return InfoRow(row, d, v)
    }

    // ---------------------------------------------------------------- buttons

    /**
     * Branded button. States: normal, pressed (darker + ripple), focused (chrome ring),
     * disabled (muted). Min height 52dp for comfortable touch targets.
     */
    fun button(label: String, kind: Kind, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(textColors(kind))
        minHeight = dp(52)
        minimumHeight = dp(52)
        stateListAnimator = null
        gravity = Gravity.CENTER
        setPadding(dp(20), 0, dp(20), 0)
        background = buttonBackground(kind)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun textColors(kind: Kind): ColorStateList {
        val normal = when (kind) {
            Kind.PRIMARY -> Color.WHITE
            Kind.OUTLINE -> c(R.color.hx_chrome)
            Kind.DANGER -> c(R.color.hx_error)
            Kind.GHOST -> c(R.color.hx_brand_light)
        }
        return ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(c(R.color.hx_text_disabled), normal)
        )
    }

    private fun shape(f1: Int, f2: Int, stroke: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(f1, f2)).apply {
            cornerRadius = dpf(RADIUS_BTN)
            setStroke(dp(strokeDp), stroke)
        }

    private fun buttonBackground(kind: Kind): RippleDrawable {
        val clear = Color.TRANSPARENT
        val chrome = c(R.color.hx_chrome)
        val normal: GradientDrawable
        val pressed: GradientDrawable
        when (kind) {
            Kind.PRIMARY -> {
                normal = shape(c(R.color.hx_brand_start), c(R.color.hx_brand_dark), withAlpha(chrome, 0x40), 1)
                pressed = shape(c(R.color.hx_brand), c(R.color.hx_brand_pressed), withAlpha(chrome, 0x40), 1)
            }
            Kind.OUTLINE -> {
                normal = shape(clear, clear, c(R.color.hx_brand_light), 1)
                pressed = shape(withAlpha(c(R.color.hx_brand), 0x55), withAlpha(c(R.color.hx_brand), 0x55), c(R.color.hx_brand_light), 1)
            }
            Kind.DANGER -> {
                normal = shape(clear, clear, c(R.color.hx_error), 1)
                pressed = shape(withAlpha(c(R.color.hx_error), 0x33), withAlpha(c(R.color.hx_error), 0x33), c(R.color.hx_error), 1)
            }
            Kind.GHOST -> {
                normal = shape(clear, clear, clear, 0)
                pressed = shape(withAlpha(Color.WHITE, 0x14), withAlpha(Color.WHITE, 0x14), clear, 0)
            }
        }
        val focused = shape(
            if (kind == Kind.PRIMARY) c(R.color.hx_brand_start) else clear,
            if (kind == Kind.PRIMARY) c(R.color.hx_brand_dark) else clear,
            chrome, 2
        )
        val disabled = shape(
            withAlpha(c(R.color.hx_surface_raised), 0x99), withAlpha(c(R.color.hx_surface_raised), 0x99),
            c(R.color.hx_divider), 1
        )
        val states = StateListDrawable().apply {
            addState(intArrayOf(-android.R.attr.state_enabled), disabled)
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
        val mask = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dpf(RADIUS_BTN)
        }
        return RippleDrawable(ColorStateList.valueOf(c(R.color.hx_ripple)), states, mask)
    }

    // ---------------------------------------------------------------- motion

    /** Restrained entrance: short fade + 14dp slide, staggered by 60ms. Honors the system animation scale. */
    fun reveal(views: List<View>) {
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dpf(14)
            v.animate().alpha(1f).translationY(0f).setStartDelay(60L * i).setDuration(260L).start()
        }
    }

    companion object {
        const val RADIUS_CARD = 22
        const val RADIUS_BTN = 16
        const val PAD_CARD = 18
    }
}
