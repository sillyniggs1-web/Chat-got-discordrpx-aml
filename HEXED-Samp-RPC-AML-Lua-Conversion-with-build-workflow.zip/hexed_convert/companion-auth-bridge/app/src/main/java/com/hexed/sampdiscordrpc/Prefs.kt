package com.hexed.sampdiscordrpc

import android.content.Context

/** Tiny settings store: whether the user wants the service running (restored after reboot / kill). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("rpc", Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun askedBattery(c: Context): Boolean = sp(c).getBoolean("asked_battery", false)
    fun setAskedBattery(c: Context) = sp(c).edit().putBoolean("asked_battery", true).apply()
}
