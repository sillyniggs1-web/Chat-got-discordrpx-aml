// SampDiscordRpc native core
// UDP listener (127.0.0.1:<port>) + Discord Social SDK rich presence, one worker thread.

#define DISCORDPP_IMPLEMENTATION // exactly one file
#include "discordpp.h"

#include <jni.h>
#include <android/log.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#define TAG "SampDiscordRpc"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::atomic<bool> g_run{false};
std::thread g_thread;
std::mutex g_mu;
std::string g_status = "Stopped";

// login state (OAuth route). Without login we use the local Discord app instead.
std::atomic<bool> g_authed{false};    // a token was accepted and Connect() was called
std::atomic<bool> g_ready{false};     // SDK status is Ready
std::atomic<bool> g_loginReq{false};  // Kotlin asked for the login flow
std::atomic<bool> g_repush{false};    // force a presence update (e.g. right after Ready)
std::string g_tokenPath;              // file that stores only the refresh token
std::atomic<bool> g_needRefresh{false};   // reconnect through the saved login (token expiring / connection dropped)
std::atomic<bool> g_refreshing{false};    // a RefreshToken request is in flight (refresh tokens rotate: never run two)
std::atomic<bool> g_authorizeReq{false};  // saved login is invalid: open the Discord authorize screen
std::atomic<bool> g_logoutReq{false};     // forget the saved login

void setStatus(const std::string& s) {
    std::lock_guard<std::mutex> lock(g_mu);
    g_status = s;
}

struct State {
    bool active = false;
    std::string nick, server, ip;
    int port = 7777;
    int players = 0;
    long long start = 0;
};

std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == sep) { out.push_back(cur); cur.clear(); }
        else cur.push_back(c);
    }
    out.push_back(cur);
    return out;
}

// cut to at most `max` bytes without splitting a UTF-8 character
std::string clip(const std::string& s, size_t max) {
    if (s.size() <= max) return s;
    size_t n = max;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
    return s.substr(0, n);
}

// HXRPC1 \t STATE \t nick \t id \t server \t ip \t port \t players \t startEpoch
// HXRPC1 \t BYE
bool parse(const std::string& msg, State& out, bool& bye) {
    auto f = split(msg, '\t');
    if (f.size() < 2 || f[0] != "HXRPC1") return false;
    if (f[1] == "BYE") { bye = true; return true; }
    if (f[1] != "STATE" || f.size() < 9) return false;
    bye = false;
    out.active = true;
    out.nick = f[2];
    out.server = f[4];
    out.ip = f[5];
    out.port = std::atoi(f[6].c_str());
    out.players = std::atoi(f[7].c_str());
    out.start = std::atoll(f[8].c_str());
    return true;
}

std::string readRefresh() {
    std::string out;
    if (FILE* f = std::fopen(g_tokenPath.c_str(), "r")) {
        char b[1024];
        while (std::fgets(b, sizeof(b), f)) out += b;
        std::fclose(f);
    }
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r' || out.back() == ' ')) out.pop_back();
    return out;
}

void writeRefresh(const std::string& token) {
    // write to a temp file and rename: a kill in the middle must never lose the (rotated) token
    const std::string tmp = g_tokenPath + ".tmp";
    if (FILE* f = std::fopen(tmp.c_str(), "w")) {
        const bool ok = std::fputs(token.c_str(), f) >= 0;
        std::fclose(f);
        chmod(tmp.c_str(), 0600);
        if (ok) std::rename(tmp.c_str(), g_tokenPath.c_str());
    }
}

void eraseRefresh() {
    std::remove(g_tokenPath.c_str());
    std::remove((g_tokenPath + ".tmp").c_str());
}

void connectWith(const std::shared_ptr<discordpp::Client>& client,
                 discordpp::AuthorizationTokenType type, const std::string& access) {
    client->UpdateToken(type, access, [client](discordpp::ClientResult r) {
        if (!r.Successful()) {
            setStatus("Token update failed, retrying: " + std::string(r.Error()));
            g_needRefresh = true;
            return;
        }
        g_authed = true;
        // already connected (token just renewed in the background): nothing more to do
        if (client->GetStatus() == discordpp::Client::Status::Disconnected) {
            setStatus("Connecting to Discord...");
            client->Connect();
        }
    });
}

// swap the saved refresh token for a fresh access token, then connect. Used on start, when the
// token is about to expire and after a dropped connection, so the user never has to log in again.
void tryRefresh(const std::shared_ptr<discordpp::Client>& client, uint64_t appId, bool loginIfInvalid) {
    const std::string rt = readRefresh();
    if (rt.empty()) return;
    if (g_refreshing.exchange(true)) return;
    setStatus("Restoring saved Discord login...");
    client->RefreshToken(appId, rt, [client, rt, loginIfInvalid](discordpp::ClientResult r, std::string access,
                                             std::string refresh, discordpp::AuthorizationTokenType type,
                                             int32_t, std::string) {
        g_refreshing = false;
        if (!r.Successful()) {
            const int http = static_cast<int>(r.Status());
            if (http == 400 || http == 401 || http == 403) {
                // Discord rejected the refresh token (revoked or expired): the only case that needs a new login
                if (readRefresh() == rt) eraseRefresh();
                g_authed = false;
                setStatus("Saved login expired - tap Log in with Discord");
                if (loginIfInvalid) g_authorizeReq = true;
            } else {
                setStatus("Discord unreachable, retrying: " + std::string(r.Error()));
                g_needRefresh = true;   // network problem: keep the saved login and try again
            }
            return;
        }
        if (!refresh.empty()) writeRefresh(refresh);
        connectWith(client, type, access);
    });
}

// OAuth2 + PKCE; opens the Discord app (or a browser) so the user can approve
void startLogin(const std::shared_ptr<discordpp::Client>& client, uint64_t appId) {
    auto verifier = client->CreateAuthorizationCodeVerifier();
    discordpp::AuthorizationArgs args{};
    args.SetClientId(appId);
    args.SetScopes(discordpp::Client::GetDefaultPresenceScopes());
    args.SetCodeChallenge(verifier.Challenge());
    // log in as an individual: installs the app on the user's account (counts under "Individual Users")
    args.SetIntegrationType(discordpp::IntegrationType::UserInstall);
    setStatus("Opening Discord to authorize...");
    client->Authorize(args, [client, verifier, appId](discordpp::ClientResult r, std::string code,
                                                      std::string redirectUri) {
        if (!r.Successful()) {
            setStatus("Authorize failed: " + std::string(r.Error()));
            return;
        }
        setStatus("Authorized, getting token...");
        client->GetToken(appId, code, verifier.Verifier(), redirectUri,
            [client](discordpp::ClientResult r2, std::string access, std::string refresh,
                     discordpp::AuthorizationTokenType type, int32_t, std::string) {
                if (!r2.Successful()) {
                    setStatus("Token exchange failed: " + std::string(r2.Error()));
                    return;
                }
                if (!refresh.empty()) writeRefresh(refresh);
                connectWith(client, type, access);
            });
    });
}

void push(const std::shared_ptr<discordpp::Client>& client, const State& s) {
    if (!s.active) {
        client->ClearRichPresence();
        setStatus("Presence cleared (not in a server)");
        return;
    }
    std::string details = s.server.empty() ? std::string("SA-MP server") : s.server;
    std::string who = s.nick.empty() ? std::string("player") : s.nick;
    std::string state = who + " \xE2\x80\xA2 " + s.ip + ":" + std::to_string(s.port);

    discordpp::Activity a;
    a.SetType(discordpp::ActivityTypes::Playing);
    a.SetName("San Andreas Multiplayer");
    a.SetDetails(clip(details, 120));
    a.SetState(clip(state, 120));
    if (s.start > 0) {
        discordpp::ActivityTimestamps ts;
        ts.SetStart(static_cast<uint64_t>(s.start)); // unix seconds, counts up as "elapsed"
        a.SetTimestamps(ts);
    }

    client->UpdateRichPresence(a, [](discordpp::ClientResult r) {
        if (r.Successful()) setStatus("Presence active");
        else setStatus("Presence failed: " + std::string(r.Error()));
    });
}

void worker(uint64_t appId, int port) {
    using clock = std::chrono::steady_clock;
    using std::chrono::seconds;

    auto client = std::make_shared<discordpp::Client>();
    client->AddLogCallback([](auto message, auto severity) {
        LOGI("[sdk] %s", std::string(message).c_str());
    }, discordpp::LoggingSeverity::Info);

    // raw pointer on purpose: these callbacks live as long as the client, a shared_ptr would be a cycle
    discordpp::Client* raw = client.get();
    client->SetStatusChangedCallback([raw](discordpp::Client::Status status,
                                           discordpp::Client::Error error, int32_t) {
        if (status == discordpp::Client::Status::Ready) {
            g_ready = true;
            g_repush = true;
            std::string name = "Discord";
            if (auto u = raw->GetCurrentUserV2()) name = u->DisplayName();
            setStatus("Logged in as " + name + " (login saved)");
        } else {
            g_ready = false;
            if (error != discordpp::Client::Error::None)
                setStatus("Discord connection error: " + discordpp::Client::ErrorToString(error));
            else
                setStatus("Discord: " + discordpp::Client::StatusToString(status));
            // fully disconnected while we should be logged in: reconnect through the saved login
            if (status == discordpp::Client::Status::Disconnected && g_authed && g_run) g_needRefresh = true;
        }
    });
    client->SetTokenExpirationCallback([]() { g_needRefresh = true; });

    // Without login: rich presence through the local Discord app (no Connect()).
    client->SetApplicationId(appId);
    tryRefresh(client, appId, false);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        setStatus("socket() failed");
        g_run = false;
        return;
    }
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        setStatus("bind to 127.0.0.1:" + std::to_string(port) + " failed");
        close(fd);
        g_run = false;
        return;
    }
    timeval tv{0, 100000}; // 100 ms, so RunCallbacks keeps ticking
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    setStatus("Waiting for game data on 127.0.0.1:" + std::to_string(port));

    State cur;
    std::string lastKey;
    auto lastPush = clock::time_point{};
    auto lastPacket = clock::now();
    auto nextRefresh = clock::time_point{};
    char buf[2048];

    while (g_run) {
        if (g_logoutReq.exchange(false)) {
            g_authed = false;
            g_ready = false;
            g_needRefresh = false;
            eraseRefresh();
            client->Disconnect();
            setStatus("Logged out. Tap Log in with Discord to sign in again");
        }
        if (g_authorizeReq.exchange(false)) startLogin(client, appId);
        if (g_loginReq.exchange(false)) {
            if (g_ready) setStatus("Already logged in (saved). Use Log out to switch account");
            else if (!readRefresh().empty()) tryRefresh(client, appId, true);   // reuse the saved login
            else startLogin(client, appId);                                    // first time only
        }
        if (g_needRefresh && clock::now() >= nextRefresh) {
            g_needRefresh = false;
            nextRefresh = clock::now() + seconds(15);   // backoff between reconnect attempts
            tryRefresh(client, appId, false);
        }

        ssize_t n = recvfrom(fd, buf, sizeof(buf) - 1, 0, nullptr, nullptr);
        auto now = clock::now();
        if (n > 0) {
            State st;
            bool bye = false;
            if (parse(std::string(buf, static_cast<size_t>(n)), st, bye)) {
                lastPacket = now;
                cur = bye ? State{} : st;
            }
        }
        // the game script stopped sending: treat it as "left the server"
        if (cur.active && now - lastPacket > seconds(10)) cur = State{};

        std::string key = cur.active
            ? cur.server + "|" + cur.ip + ":" + std::to_string(cur.port) + "|" + cur.nick + "|" + std::to_string(cur.start)
            : std::string();
        if (g_repush.exchange(false)) lastKey = "\x01force";
        const bool canPush = !g_authed || g_ready;  // logged in: wait until Ready
        if (canPush && (key != lastKey || (cur.active && now - lastPush > seconds(30)))) {
            push(client, cur);
            lastKey = key;
            lastPush = now;
        }
        discordpp::RunCallbacks();
    }

    client->ClearRichPresence();
    for (int i = 0; i < 5; ++i) {
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    close(fd);
}

} // namespace

extern "C" {

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_start(JNIEnv* env, jclass, jlong appId, jint port, jstring dir) {
    if (g_run.exchange(true)) return;
    if (const char* d = env->GetStringUTFChars(dir, nullptr)) {
        g_tokenPath = std::string(d) + "/discord_login.txt";
        env->ReleaseStringUTFChars(dir, d);
    }
    g_authed = false;
    g_ready = false;
    g_needRefresh = false;
    g_refreshing = false;
    g_logoutReq = false;
    if (g_thread.joinable()) g_thread.join();
    g_thread = std::thread(worker, static_cast<uint64_t>(appId), static_cast<int>(port));
}

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_login(JNIEnv*, jclass) {
    g_loginReq = true;
}

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_logout(JNIEnv*, jclass) {
    if (g_run) g_logoutReq = true;   // when the service is not running Kotlin just deletes the token file
}

JNIEXPORT void JNICALL Java_com_hexed_sampdiscordrpc_Native_stop(JNIEnv*, jclass) {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    setStatus("Stopped");
}

JNIEXPORT jstring JNICALL Java_com_hexed_sampdiscordrpc_Native_status(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_mu);
    return env->NewStringUTF(g_status.c_str());
}

} // extern "C"
