# Change report: UI redesign (1.2 to 1.3)

## Detected project
Kotlin + Android Views built in code (no XML layouts, no Compose), `Activity` based, native C++ (NDK 27, CMake) with
the Discord Social SDK AAR. compileSdk/targetSdk 34, minSdk 24. Package `com.hexed.sampdiscordrpc` is unchanged.
Source is available, so nothing had to be reverse engineered from an APK.

## Screen inventory
| Screen | Status |
|---|---|
| Main screen (only screen of the app) | Redesigned: logo header, connection card, Service / Discord account / Background sections, last-crash card |
| Launch / splash | New: branded launch background (pre-12) and branded system splash (12+); no added delay |
| App icon | New: logo-based adaptive + legacy icons |
| Foreground-service notification | Restyled: logo-derived glyph, brand accent color, tap opens the app |
| Discord login screen (`AuthenticationActivity`) | Not redesignable: it is a transparent bridge activity inside the Discord SDK, the actual login page is Discord's own |
| System dialogs (notification permission, battery exemption) | Owned by Android |

## What changed
New: `Ui.kt` (design system), `res/values/colors.xml`, `res/values/themes.xml`, `res/values-v31/themes.xml`, launch/icon
drawables, logo mipmaps, `docs/`. Rewritten: `MainActivity.kt` (UI only). Edited: `AndroidManifest.xml` (icon, roundIcon, theme),
`RpcService.kt` (notification icon, color, tap action), `build.gradle.kts` (version 1.3, code 6).

Behavior preserved (same calls as before): Start service, Stop service (ACTION_STOP), Log in with Discord (starts service then
`Native.login()`), Log out (deletes saved token files, `Native.logout()`), Battery settings (direct exemption request),
one-time battery prompt, POST_NOTIFICATIONS request, SDK engine-activity setup, crash logger and last-crash display, 1 s status refresh.
Small additions: status dot colors, "Saved Discord login" and "Background battery" rows, Log out is disabled while nothing is saved.
Native code, Lua bridge and permissions are untouched.

## Build instructions
1. Android Studio (Koala or newer) with SDK 34 and NDK 27.0.12077973, open the `SampDiscordRpc` folder (it creates the Gradle wrapper; the zip has none).
   Or from a shell with Gradle 8.7+: `gradle wrapper && ./gradlew assembleDebug`.
2. Optional: `DISCORD_APP_ID=<id>` environment variable (default 1566671569479147600).
3. Output: `app/build/outputs/apk/debug/app-debug.apk`. Release signing is up to you; no keys were touched.

## Testing report
Verified here:
- All XML (resources and manifest) is well-formed; every `R.color` / `R.drawable` / `@mipmap` / `@style` reference resolves; no unused color tokens.
- Kotlin files have balanced brackets; `rpc.cpp` (unchanged this round) compiled as a syntax check against the SDK header earlier.
- Text/background contrast ratios computed (see DESIGN_SYSTEM.md); adaptive icon rendered under circle and squircle masks to check the mark isn't cropped.

NOT verified (no Android SDK, Gradle, Kotlin compiler or device in this environment):
- The Kotlin compiles and the project builds, so **no APK was produced**.
- How the screen actually looks and behaves on a device or emulator, landscape and tablet layout, display cutouts, TalkBack.
- Android lint, automated tests (the project has none), settings persistence, the Log in flow after the earlier crash fix.
Expect to fix small compile errors on the first build; send me the Gradle output and I'll correct them.
