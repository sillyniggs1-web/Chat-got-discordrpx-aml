# Native AML adapter integration status

The uploaded project is a JNI library built for an Android app, not an AML mod. Its exported functions are named `Java_com_hexed_sampdiscordrpc_Native_*`; those are not evidence of an AML plugin entry point.

AML's public repository documents `template_of_mod` as the starter template and places mods under `/sdcard/Android/data/<game-package>/mods`. The exact template/API headers are not part of the uploaded ZIP, and the current environment could not retrieve the GitHub source. To avoid inventing AML macros or lifecycle calls, this folder intentionally does not pretend to be a drop-in AML `.so`.

To complete the native `.so` layer:
1. Obtain the official `AndroidModLoader/template_of_mod` from the exact AML revision used by the Nezuko APK.
2. Copy the official template files into this folder.
3. Adapt the transport lifecycle to that template's documented mod entry point.
4. Keep the Discord SDK/OAuth work in the companion app unless the SDK's Android authentication requirements are deliberately reimplemented.
5. Verify target package, ABI, linker dependencies, and load order on-device.

The Lua sender currently communicates directly with the existing companion UDP listener, so this native adapter is not required for the basic bridge path. It is a separate step for the user's requested fully native AML packaging.
