script_name("HEXED Samp RPC Bridge")
script_author("HEXED")
script_description("Sends SA-MP session state to the HEXED Discord RPC companion bridge")

-- Compatibility note:
-- This script targets MonetLoader's MoonLoader-compatible Lua environment.
-- Game API names below are common MoonLoader APIs but must be checked against
-- the exact MonetLoader build bundled with the Nezuko client.
-- It uses LuaJIT FFI for localhost UDP and does not require LuaSocket.

local ffi = require("ffi")
local ok, _ = pcall(function()
    ffi.cdef[[
        typedef unsigned int hx_u32;
        typedef unsigned short hx_u16;
        typedef unsigned char hx_u8;
        typedef unsigned int hx_socklen_t;
        int socket(int domain, int type, int protocol);
        int sendto(int sockfd, const void *buf, unsigned long len, int flags,
                   const void *dest_addr, hx_socklen_t addrlen);
        int close(int fd);
        hx_u32 inet_addr(const char *cp);
        hx_u16 htons(hx_u16 hostshort);
    ]]
end)
if not ok then
    print("[HEXED RPC] FFI declarations unavailable; script will stop.")
    return
end

ffi.cdef[[
    struct hx_sockaddr_in {
        short sin_family;
        unsigned short sin_port;
        struct { unsigned int s_addr; } sin_addr;
        unsigned char sin_zero[8];
    };
]]

local AF_INET, SOCK_DGRAM = 2, 2
local PORT = 6464
local fd = -1
local lastPacket = ""
local lastSend = 0
local startEpoch = os.time()
local active = false

local function safeCall(name, ...)
    local fn = _G[name]
    if type(fn) ~= "function" then return nil end
    local okCall, a, b, c = pcall(fn, ...)
    if okCall then return a, b, c end
    return nil
end

local function udpOpen()
    if fd >= 0 then return true end
    fd = ffi.C.socket(AF_INET, SOCK_DGRAM, 0)
    if fd < 0 then
        print("[HEXED RPC] Could not create UDP socket.")
        return false
    end
    return true
end

local function udpSend(message)
    if not udpOpen() then return false end
    local addr = ffi.new("struct hx_sockaddr_in")
    addr.sin_family = AF_INET
    addr.sin_port = ffi.C.htons(PORT)
    addr.sin_addr.s_addr = ffi.C.inet_addr("127.0.0.1")
    local sent = ffi.C.sendto(fd, message, #message, 0, addr, ffi.sizeof(addr))
    return sent == #message
end

local function cleanField(value, maxBytes)
    value = tostring(value or "")
    value = value:gsub("[\t\r\n]", " "):gsub("|", "/")
    if #value > maxBytes then value = value:sub(1, maxBytes) end
    return value
end

local function getState()
    -- MoonLoader-compatible API probes. If Nezuko/MonetLoader uses different
    -- names, update this adapter only; the wire protocol stays unchanged.
    local ready = safeCall("isSampAvailable")
    if not ready then return nil end

    local ped = _G.PLAYER_PED or 0
    local playerId = safeCall("sampGetPlayerIdByCharHandle", ped) or 0
    local nick = safeCall("sampGetPlayerNickname", playerId)
    if not nick or nick == "" then nick = safeCall("sampGetPlayerNickname", 0) end
    local server = safeCall("sampGetCurrentServerName") or "SA-MP"
    local ip, port = safeCall("sampGetCurrentServerAddress")
    local players = safeCall("sampGetPlayerCount") or 0
    
    return {
        nick = cleanField(nick or "Player", 48),
        id = tonumber(playerId) or 0,
        server = cleanField(server, 64),
        ip = cleanField(ip or "unknown", 48),
        port = tonumber(port) or 7777,
        players = tonumber(players) or 0,
        start = startEpoch
    }
end

local function sendBye()
    udpSend("HXRPC1\tBYE")
    active = false
end

function main()
    print("[HEXED RPC] Bridge script started. Companion service must be running on UDP 127.0.0.1:6464.")
    while true do
        wait(1000)
        local s = getState()
        if s then
            local packet = string.format(
                "HXRPC1\tSTATE\t%s\t%d\t%s\t%s\t%d\t%d\t%d",
                s.nick, s.id, s.server, s.ip, s.port, s.players, s.start
            )
            if packet ~= lastPacket or os.time() - lastSend >= 5 then
                if udpSend(packet) then
                    lastPacket = packet
                    lastSend = os.time()
                    active = true
                end
            end
        elseif active then
            sendBye()
        end
    end
end

function onScriptTerminate(script, quitGame)
    if script == thisScript() then
        sendBye()
        if fd >= 0 then ffi.C.close(fd); fd = -1 end
    end
end
