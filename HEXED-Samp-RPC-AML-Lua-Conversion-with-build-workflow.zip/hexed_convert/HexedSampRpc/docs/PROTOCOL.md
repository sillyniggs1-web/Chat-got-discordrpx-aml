# HXRPC1 local UDP protocol

Destination: `127.0.0.1:6464` (IPv4 UDP)

## STATE
Nine tab-separated fields:
1. `HXRPC1`
2. `STATE`
3. player nickname
4. player ID
5. server display name
6. server address
7. server port
8. player count
9. Unix start timestamp in seconds

The C++ parser in the original companion app requires at least nine fields and consumes fields 3, 5, 6, 7, 8, and 9 (1-based). Player ID is currently accepted but not displayed.

## BYE
`HXRPC1<TAB>BYE`

This clears the active game state in the companion service.

## Manual smoke test
With the companion app service running, send a test datagram from a trusted local terminal:
`printf 'HXRPC1\tSTATE\tTestPlayer\t1\tTest Server\t127.0.0.1\t7777\t20\t1790000000' | nc -u -w1 127.0.0.1 6464`
