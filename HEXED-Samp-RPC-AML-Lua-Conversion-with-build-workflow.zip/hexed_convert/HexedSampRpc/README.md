# HEXED Samp RPC — conversion workspace (v1)

This package preserves the original Android Discord Social SDK companion app as an **authentication/RPC bridge** and adds a Lua session-state sender intended for MonetLoader-compatible environments.

## Important status

This is a **source conversion workspace**, not a verified final native AML `.so` for Nezuko 1.0.3 TESTING. The uploaded project contains a Kotlin/Android service and a C++ Discord Social SDK client; the SDK's OAuth flow depends on Android activity/redirect handling. Keeping the original companion app as a minimal bridge is the least destructive way to preserve that verified design.

The original ZIP did not contain the `Discord_RPC_Bridge.lua` referenced by its README, and the exact Nezuko/MonetLoader API build was not included. The Lua adapter therefore probes common MoonLoader-compatible API names and needs on-device verification. No undocumented AML entry-point macro is fabricated in `native-aml-adapter/`.

## Components

- `companion-auth-bridge/` — original source copied unchanged from `SampDiscordRpc-v1-beta.zip`; handles Discord Social SDK login, token refresh, reconnection, and presence.
- `HexedSampRpc/lua/HexedDiscordRPC.lua` — LuaJIT FFI UDP sender. It sends the original protocol to `127.0.0.1:6464`.
- `HexedSampRpc/native-aml-adapter/` — notes on integrating with the exact official AML template/API. It deliberately contains no invented AML lifecycle code.
- `HexedSampRpc/docs/` — protocol and test checklist.

## Build the companion bridge

1. Open `companion-auth-bridge/` in Android Studio.
2. Set `DISCORD_APP_ID` according to the existing `app/build.gradle.kts` instructions.
3. Use an Android SDK/NDK version compatible with the Gradle and CMake versions already declared in the project.
4. Ensure the `discord_partner_sdk.aar` is present under `app/libs/` (it is included in this archive).
5. Build and install the app. Sign in with Discord, then start the service.
6. Do not remove the Android OAuth redirect Activity/manifest configuration; it is needed for login.

## Install Lua script for testing

1. Confirm that Nezuko's installed loader is MonetLoader or a compatible loader that supports LuaJIT `ffi`.
2. Copy `HexedDiscordRPC.lua` into that loader's scripts directory. MonetLoader builds commonly use the game package's `Android/media/<package>/` data layout; use the path documented by the exact installed loader.
3. Start the companion app's service first.
4. Launch Nezuko SA-MP and join a server.
5. Check the companion app status and Discord activity.

The script expects the companion service to be listening on UDP port `6464`. The protocol is tab-separated:
`HXRPC1<TAB>STATE<TAB>nick<TAB>id<TAB>server<TAB>ip<TAB>port<TAB>players<TAB>startEpoch`
and on leaving:
`HXRPC1<TAB>BYE`.

## Required verification before calling this complete

- Confirm the installed loader and its version.
- Verify the exact names and return values of `isSampAvailable`, `sampGetPlayerNickname`, `sampGetPlayerIdByCharHandle`, `sampGetCurrentServerName`, `sampGetCurrentServerAddress`, and `sampGetPlayerCount` in that build.
- Confirm `ffi` is enabled and `sendto` is permitted.
- Test both `arm64-v8a` and `armeabi-v7a` only if the target process ABI requires them.
- Inspect logcat and the loader's script log if the script fails.
- A native AML `.so` must be created using the official AML `template_of_mod` for the exact AML revision installed in the game. Do not simply rename a JNI library; AML's mod declaration/entry point is loader-version-specific.

## Security

The companion app stores OAuth refresh credentials in its private app storage. Do not print tokens to logs or send them through the Lua bridge. The Lua bridge sends only game/session metadata to localhost.
