# Extract and compile the native `.so`

This workflow extracts `HEXED-Samp-RPC-AML-Lua-Conversion.zip`, then invokes the Android Gradle Plugin's CMake task to compile the existing native JNI library. The expected output is `libsampdiscordrpc.so` for each configured ABI (`arm64-v8a` and `armeabi-v7a`).

## GitHub Actions workflow

1. Create a GitHub repository and place these files at its root:
   - `HEXED-Samp-RPC-AML-Lua-Conversion.zip`
   - `.github/workflows/build-native-so.yml`
2. Commit and push the files.
3. Open **Actions → Extract and build native .so → Run workflow**.
4. When it completes, download the `hexed-samp-rpc-native-so` artifact. It contains the compiled shared libraries.

The ZIP is deliberately required as a repository file; GitHub Actions cannot access a ZIP that exists only on your phone or computer.

## Local build

Prerequisites: JDK 17, Gradle 8.7, Android SDK, Android NDK `27.0.12077973`, and CMake `3.22.1`.

Run:

```bash
./build-native-so.sh ./HEXED-Samp-RPC-AML-Lua-Conversion.zip
```

Output is copied under `dist/native-so/`.

## Important: JNI `.so` versus AML plugin `.so`

This builds the native library declared by the companion app's current `CMakeLists.txt` (`libsampdiscordrpc.so`). It exports JNI methods used by the Android app. It is **not automatically an AML-loadable plugin**. The conversion archive explicitly documents that the official AML template and exact target AML entry points still need to be integrated before the output can be loaded as a native AML mod. Do not install this JNI library into the game's AML mod folder and expect it to work as a plugin.
