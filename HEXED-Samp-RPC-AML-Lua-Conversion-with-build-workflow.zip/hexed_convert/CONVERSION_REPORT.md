# Conversion report

## Preserved from source
- Original Kotlin UI, foreground service, boot receiver, preferences, JNI wrapper, C++ Discord Social SDK client, and bundled SDK AAR.
- Existing UDP protocol `HXRPC1` and port `6464`.
- Existing OAuth2/PKCE and refresh-token behavior remain in the companion source.

## Added
- LuaJIT FFI UDP sender that emits the protocol already parsed by the original C++ app.
- Build/install/test documentation and explicit integration limitations.

## Not yet verified / not claimed
- No APK build was run in this environment.
- No target device or Nezuko 1.0.3 TESTING runtime was available.
- The Lua game API names must be verified against the installed MonetLoader build.
- A native AML `.so` is not yet emitted because the official AML template and exact AML revision are absent. Fabricating an entry point would violate the requirement not to invent APIs.
- The Discord SDK cannot be declared fully functional inside the game process until ABI/linker/authentication behavior is tested.

## Rationale
The source's Discord Social SDK is coupled to Android OAuth redirect handling and Android service lifecycle. Preserving the current companion bridge keeps authentication behavior intact while the Lua side is converted first. The next step to achieve a truly standalone native AML package is to integrate against the actual AML template used by the target build.
