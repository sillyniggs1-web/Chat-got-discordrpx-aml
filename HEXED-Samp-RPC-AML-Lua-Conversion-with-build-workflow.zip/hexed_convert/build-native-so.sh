#!/usr/bin/env bash
# Extract the conversion ZIP and build the Android JNI shared library (.so).
# Usage: ./build-native-so.sh [path/to/HEXED-Samp-RPC-AML-Lua-Conversion.zip]
set -euo pipefail

ZIP_PATH="${1:-HEXED-Samp-RPC-AML-Lua-Conversion.zip}"
if [[ ! -f "$ZIP_PATH" ]]; then
  echo "ZIP not found: $ZIP_PATH" >&2
  echo "Usage: $0 path/to/HEXED-Samp-RPC-AML-Lua-Conversion.zip" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")" && pwd)"
WORK="$ROOT/.build-native-so"
rm -rf "$WORK"
mkdir -p "$WORK"
unzip -q "$ZIP_PATH" -d "$WORK"
PROJECT="$WORK/hexed_convert/companion-auth-bridge"
if [[ ! -f "$PROJECT/app/src/main/cpp/CMakeLists.txt" ]]; then
  echo 'The ZIP does not contain the expected companion-auth-bridge CMake project.' >&2
  exit 3
fi

if ! command -v java >/dev/null || ! command -v gradle >/dev/null; then
  echo 'Install JDK 17, Gradle 8.7, Android SDK, NDK 27.0.12077973, and CMake 3.22.1 first.' >&2
  exit 4
fi

cd "$PROJECT"
gradle --no-daemon :app:externalNativeBuildDebug
mkdir -p "$ROOT/dist/native-so"
find "$PROJECT/app/build" -type f -name '*.so' -exec cp --parents '{}' "$ROOT/dist/native-so/" \;
if ! find "$ROOT/dist/native-so" -type f -name 'libsampdiscordrpc.so' | grep -q .; then
  echo 'Build finished but libsampdiscordrpc.so was not found. Review the Gradle/CMake output.' >&2
  exit 5
fi
echo "Native libraries copied to: $ROOT/dist/native-so"
find "$ROOT/dist/native-so" -type f -name '*.so' -print
